"""Interface URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.10/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.conf.urls import url, include
    2. Add a URL to urlpatterns:  url(r'^blog/', include('blog.urls'))
"""
from django.conf.urls import url
from django.contrib import admin
from interface import views,defs


urlpatterns = [

    # 未登录首页
    url(r'^$', defs.start, name="start"),
    # 登录方法
    url(r'^login$', defs.login1, name="login"),
    url(r'^login/ajax_login$', defs.ajax_login, name="ajax_login"),
    url(r'^login_process$', defs.login_process, name="login_process"),
    # 注销方法
    url(r'^cancel$', defs.cancel, name="cancel"),
    # 注册方法
    url(r'^register$', defs.register, name="register"),
    url(r'^registersuccess$', defs.registersuccess, name="registersuccess"),
    url(r'^ajax_register$', defs.ajax_register, name="ajax_register"),

    url(r'^admin/', admin.site.urls),

    # 修改密码界面
    url(r'^change_password$', defs.change_password, name="change_password"),
    # 修改密码后台
    url(r'^ajax_change_password$', defs.ajax_change_password, name="ajax_change_password"),


    url(r'^index$', views.index, name='index'),

    # url(r'case_edit/(?P<item>.*)/(?P<case_id>.*)/', views.case_edit, name='case_edit'),
    # url(r'case_editcancel/(?P<item>.*)/', views.case_editcancel, name='case_editcancel'),
    # url(r'edit/(?P<md>.*)/', views.case_editcommit, name='case_editcommit'),
    # url(r'new/(?P<md>.*)/', views.case_newcommit, name='case_newcommit'),
    # url(r'delete/(?P<pj>.*)/(?P<item>.*)/', views.delete, name='delete'),
    # url(r'newcase/(?P<md>.*)/', views.case_new, name='newcase'),
    # url(r'^/$', views.test, name='test'),
    # url(r'^.*backhome/$', views.backhome, name='backhome'),
    # url(r'^.*backlib$', views.backlib, name='backlib'),
    # url(r'^caselib/(?P<md>.*)/', views.caselib,name='caselib'),
    # url(r'^allcaselib/', views.allcaselib,name='allcaselib'),
    # url(r'^tasks/', views.task,name='tasks'),
    # url(r'^pjlist/', views.projects_list,name='pjtasks'),
    # url(r'^pjtasks/(?P<pj>.*)/', views.task,name='tasks'),
    # url(r'^tasklist/(?P<pj>.*)/', views.tasklist,name='tasklist'),
    # url(r'^newtask/(?P<pj>.*)/', views.new_task,name='newtask'),
    # url(r'^taskcommit/(?P<pj>.*)/(?P<md>.*)/', views.task_editcommit,name='commit'),
    # url(r'^run/(?P<pj>.*)/(?P<id>.*)/', views.run, name='run'),
    # url(r'^run/(?P<id>.*)/', views.run_single, name='singlerun'),
    # url(r'^result/(?P<id>.*)/', views.echoresult,name='echoresult'),
    url(r'^admin/', admin.site.urls,name='admin'),
    # url(r'^modulelist$', views.md_list, name='modules'),
    url(r'^error/$', views.error, name='error'),
    # url(r'^closeM/$', views.closemonitor, name='closemonitor'),

    # 项目列表界面
    url(r'^ProjectList', views.ProjectList, name='ProjectList'),
    # 项目索引
    url(r'^ProjectIndex', views.ProjectIndex, name='ProjectIndex'),
    # 添加项目
    url(r'^AjaxAddProject', views.AjaxAddProject, name='AjaxAddProject'),
    # 删除项目
    url(r'^AjaxDeleteProject', views.AjaxDeleteProject, name='AjaxDeleteProject'),
    # 编辑项目
    url(r'^AjaxEditProject', views.AjaxEditProject, name='AjaxEditProject'),
    # 更新项目
    url(r'^AjaxUpdateProject', views.AjaxUpdateProject, name='AjaxUpdateProject'),
    # 项目URL
    url(r'^ProjectUrl', views.ProjectUrl, name='ProjectUrl'),
    # 新增项目URL的interface_id
    url(r'^InterfaceId', views.InterfaceId, name='InterfaceId'),
    # 新增interface
    url(r'^SaveProjectInterface', views.SaveProjectInterface, name='SaveProjectInterface'),
    # 删除interface
    url(r'^DeleteProjectInterface',views.DeleteProjectInterface,name='DeleteProjectInterface'),
    # 编辑interface
    url(r'^ObtainEditInterface',views.ObtainEditInterface,name='ObtainEditInterface'),
    # 保存更改后的interface
    url(r'^SaveEditInterface',views.SaveEditInterface,name='SaveEditInterface'),
    # 进入模块
    # url(r'^ModuleList', views.ModuleList, name='ModuleList'),
    # 模块列表
    # url(r'^ModuleIndex', views.ModuleIndex, name='ModuleIndex'),
    # 新增模块
    # url(r'^AjaxAddModule', views.AjaxAddModule, name='AjaxAddModule'),
    # 删除模块
    # url(r'^AjaxDeleteModule', views.AjaxDeleteModule, name='AjaxDeleteModule'),
    # 编辑模块
    # url(r'^AjaxEditModule', views.AjaxEditModule, name='AjaxEditModule'),
    # 更新模块
    # url(r'^AjaxUpdateModule', views.AjaxUpdateModule, name='AjaxUpdateModule'),
    # 用例列表
    url(r'^CaseList', views.CaseList, name='CaseList'),
    # 用例索引
    url(r'^CaseIndex', views.CaseIndex, name='CaseIndex'),
    # model选择
    url(r'^SelectModel', views.SelectModel, name='SelectModel'),
    # 显示Topic
    url(r'^ShowTopic',views.ShowTopic,name='ShowTopic'),
    # 显示URL
    url(r'^SelectURL',views.SelectURL,name='SelectURL'),
    # 添加用例
    url(r'^AjaxAddCase', views.AjaxAddCase, name='AjaxAddCase'),
    # 获取修改用例的数据
    url(r'^AjaxAlterCase', views.AjaxAlterCase, name='AjaxAlterCase'),
    # trigger select2 赋值
    url(r'^AddSelectTopic', views.AddSelectTopic, name='AddSelectTopic'),
    # trigger Select 赋值
    url(r'^AddSelectModule', views.AddSelectModule, name='AddSelectModule'),
    # trigger Select 赋值
    url(r'^AddSelectInterface', views.AddSelectInterface, name='AddSelectInterface'),
    # 修改用例的数据
    url(r'^AjaxUpdateCase', views.AjaxUpdateCase, name='AjaxUpdateCase'),
    # 删除用例
    url(r'^AjaxDeleteCase', views.AjaxDeleteCase, name='AjaxDeleteCase'),
    # 执行用例
    url(r'^ExecuteCase', views.ExecuteCase, name='ExecuteCase'),
    # 跳转页面
    url(r'^OpenHtml', views.OpenHtml, name='OpenHtml'),

    # 用例库界面
    url(r'^CaseLibrary',views.CaseLibrary,name='CaseLibrary'),
    # 模块索引
    url(r'^LibModuleIndex',views.LibModuleIndex,name='LibModuleIndex'),
    # 增加用例模块
    url(r'^AjaxAddLibModule',views.AjaxAddLibModule,name='AjaxAddLibModule'),
    # 编辑模块
    url(r'^AjaxEditLibModule', views.AjaxEditLibModule, name='AjaxEditLibModule'),
    # 更新模块
    url(r'^AjaxUpdateLibModule',views.AjaxUpdateLibModule,name='AjaxUpdateLibModule'),
    # 删除模块
    url(r'^AjaxDeleteLibModule',views.AjaxDeleteLibModule,name='AjaxDeleteLibModule'),
    # 模块列表
    url(r'^LibModuleCase',views.LibModuleCase,name='LibModuleCase'),
    # 用例界面
    url(r'^ModuleCaseIndex',views.ModuleCaseIndex,name='ModuleCaseIndex'),
    # 增加用例
    url(r'^AjaxAddM',views.AjaxAddM,name='AjaxAddM'),
    # 编辑用例
    url(r'^AjaxEditM',views.AjaxEditM,name='AjaxEditM'),
    # 更新用例
    url(r'^AjaxUpdateM',views.AjaxUpdateM,name='AjaxUpdateM'),
    # 删除用例
    url(r'^AjaxDeleteM',views.AjaxDeleteM,name='AjaxDeleteM'),

    # 任务列表
    url(r'^TaskList',views.TaskList,name='TaskList'),
    # 添加任务
    url(r'^AddTask',views.AddTask,name='AddTask'),
    # 选择项目
    url(r'^SelectProject',views.SelectProject,name='SelectProject'),
    # 项目关联模块
    url(r'^ModelCheck',views.ModelCheck,name='ModelCheck'),
    # 模块关联用例
    url(r'^CaseCheck',views.CaseCheck,name='CaseCheck'),
    # 提交任务
    url(r'^SubmitTask',views.SubmitTask,name='SubmitTask'),
    # 任务列表
    url(r'^TaskIndex',views.TaskIndex,name='TaskIndex'),
    # 删除某个任务
    url(r'^AjaxDeleteTask',views.AjaxDeleteTask,name='AjaxDeleteTask'),
    # 修改某个任务
    url(r'^AlterTask',views.AlterTask,name='AlterTask'),
    # 修改任务界面--添加项目
    url(r'^AddSelectProject',views.AddSelectProject,name='AddSelectProject'),
    # 更新指定任务
    url(r'^UpdateTask',views.UpdateTask,name='UpdateTask'),
    # 任务报告
    url(r'^TaskReport',views.TaskReport,name='TaskReport'),
    # 报告流水
    url(r'^ReportHistory',views.ReportHistory,name='ReportHistory'),
    # 报告索引
    url(r'^ReportIndex',views.ReportIndex,name='ReportIndex'),
    # 获取流水报告
    url(r'^AjaxReport',views.AjaxReport,name='AjaxReport'),

]
