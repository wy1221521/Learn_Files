#coding=utf-8
import json
import requests
import ssl
import os
import re
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "automation_test.settings")
import django
django.setup()
from django.conf import settings
from interface.models import testcases
from interface.models import interfaces
from interface.models import interface_cases
# from interface.models import test_tasks
from interface.functions import check_code,check_contents
ssl._create_default_https_context = ssl._create_unverified_context

from django.http import HttpResponse,HttpResponseRedirect
class ConfigHttp:
    def __init__(self):

        global timeout
        self.host = {}
        self.headers = {}
        self.params = {}
        self.data = {}
        self.url = {}
        self.files = {}
        self.timeout = 0


    def run(self,case_id):
        case_id = case_id.replace("\n", "")
        try:
            cases = interface_cases.objects.filter(case_id=case_id)
        except:
            print("找不到对应的用例库用例")
        else:
            print("\n#用例编号:",cases[0].case_id)
            try:
                testcase = testcases.objects.filter(test_id=cases[0].test_id)
                interface = interfaces.objects.filter(interface_id=cases[0].interface_id)
            except:
                print("找不到对应的用例库用例")
            else:
                print("#用例描述:",testcase[0].topic)
                self.url = interface[0].interface_host+interface[0].interface_url
                self.headers = cases[0].head
                self.params =  cases[0].params
                self.data = cases[0].data
                self.files = cases[0].file
                self.timeout = cases[0].timeout
                self.expeted= cases[0].expected_contents
            if cases[0].method == "POST":
                self.headers=self.headers.replace("\n","")
                self.headers=self.headers.replace("","")
                try:
                    self.headers=json.loads(self.headers)
                    self.data=json.loads(self.data)
                except:
                    pass
                else:
                    pass
                try:
                    for (k, v) in self.headers.items():
                        if k == "token" and self.headers['token']=='<exchange>':
                            self.headers[k]=self.get_token(cases[0].project_id)
                        else:
                            pass
                except:
                    print("ERROR")
                    pass
                try:
                   result=self.post()
                except:
                    print("post Error!!")
                    interface_cases.objects.filter(case_id=case_id).update(status=1)
                    # test_tasks.objects.filter(case_id=case_id).update(status=1)
                    assert False
                else:
                    print("#期待返回码：200","服务器实际返回码:", result.status_code,)
                    print("#期待返回关键字:", self.expeted, "服务器实际返回内容:", result.text)
                    if check_code(result.status_code) == 0:
                       if check_contents(self.expeted, result.text) == 0:
                           print("********测试通过********")
                           interface_cases.objects.filter(case_id=case_id).update(status=0)
                           # test_tasks.objects.filter(case_id=case_id).update(status=0)

                       else:
                            print("#[MSG]服务器返回页面验证失败")
                            print("********测试失败********\n")
                            interface_cases.objects.filter(case_id=case_id).update(status=1)
                            # test_tasks.objects.filter(case_id=case_id).update(status=1)
                            assert check_contents(self.expeted, result.text) == 0
                    else:

                       assert check_code(result.status_code) == 0
                       print("********测试失败:返回码错误********")
                       interface_cases.objects.filter(case_id=case_id).update(status=1)
                       # test_tasks.objects.filter(case_id=case_id).update(status=1)
            elif cases[0].method  == "GET":
                if cases[0].params:
                    self.url=self.url+"?"+cases[0].params
                else:
                    pass
                self.headers = self.headers.replace("\n", "")
                self.headers = self.headers.replace("", "")
                try:
                    self.headers = json.loads(self.headers)
                    self.data = json.loads(self.data)
                except:
                    pass
                else:
                    pass

                try:
                    for (k, v) in self.headers.items():
                        if k == "token" and self.headers['token']=='<exchange>':
                            self.headers[k]=self.get_token(cases[0].project_id)
                        else:
                            pass
                except:
                    print("ERROR")
                    pass
                try:
                   result=self.get()
                except:
                    print("post Error!!")
                    interface_cases.objects.filter(case_id=case_id).update(status=1)
                    # test_tasks.objects.filter(case_id=case_id).update(status=1)
                    assert False
                else:
                    print("#期待返回码：200","服务器实际返回码:", result.status_code,)
                    print("#期待返回关键字:",self.expeted,"服务器实际返回内容:", result.text)
                    if check_code(result.status_code)==0:
                        if check_contents(self.expeted, result.text) == 0:
                            print("#[MSG]服务器返回页面验证通过")
                            print("********测试通过********")
                            interface_cases.objects.filter(case_id=case_id).update(status=0)
                            # test_tasks.objects.filter(case_id=case_id).update(status=0)
                        else:

                            print("#[MSG]服务器返回页面验证失败")
                            print("********测试失败********\n")
                            interface_cases.objects.filter(case_id=case_id).update(status=1)
                            # test_tasks.objects.filter(case_id=case_id).update(status=1)
                            assert check_contents(self.expeted, result.text) == 0
                    else:
                        print("********测试失败:返回码错误********")
                        interface_cases.objects.filter(case_id=case_id).update(status=1)
                        # test_tasks.objects.filter(case_id=case_id).update(status=1)
                        assert check_code(result.status_code)==0

                # save_result(case_id, task_id, )
            else:
                print("Unkown")

    def get_token(self,pj):
        try:
            Token_case = interface_cases.objects.get(case_id="TC_TOKEN",project_id=pj)
        except:
            print("No default case")
        else:
            try:
                interface = interfaces.objects.get(interface_id=Token_case.interface_id)
            except:
                print("No interface id")
            else:
                url = interface.interface_host + interface.interface_url


                try:
                    Token_case=interface_cases.objects.get(case_id="TC_TOKEN",project_id=pj)
                except:
                    print("No default token case")
                else:

                    headers = Token_case.head.replace("\n", "")
                    headers = Token_case.head.replace("", "")
                    data=Token_case.data
                    try:
                        headers = json.loads(headers)
                        data = json.loads(Token_case.data)
                    except:
                        pass
                    else:
                        pass

                    try:
                        response = requests.post(url=url, headers=headers, data=data)
                    except:
                        print("post error")
                        pass
                    else:
                        try:
                            settings.TOKEN=re.match('.*\"Token\":\"(\w+)\",',response.text ).group(1)
                        except:
                            print("密码错误")
                            return HttpResponseRedirect('/error/')
                        else:
                            ''''''
                return settings.TOKEN

    def set_headers(self, header):
        self.headers = header

    def set_params(self, param):
        self.params = param

    def set_data(self, data):
        self.data = data

    def set_files(self, file):
        self.files = file

    # 定义get方法
    def get(self):
        try:
            #print("URL:",self.url,type(self.url),"\nHEADER:",self.headers,type(self.headers), "\ndata:",self.data,type(self.data))

            if self.timeout:
                response = requests.get(self.url, params=self.params, headers=self.headers, timeout=self.timeout)
            else:
                response = requests.get(self.url, params=self.params, headers=self.headers)
            response.encoding="UTF-8"
            #response.raise_for_status()
        except TimeoutError:

            return None
        else:
            return response

    # 定义post方法
    def post(self):

        try:
            # print("URL:",self.url,type(self.url),"\nHEADER:",self.headers,type(self.headers), "\ndata:",self.data,type(self.data))
            if self.timeout:
                response = requests.post(self.url, headers=self.headers, data=self.data, files=self.files, timeout=self.timeout)
            else:
                response = requests.post(self.url, headers=self.headers, data=self.data)
            #response.encoding = "UTF-8"
            #response.raise_for_status()
        except TimeoutError:
            return None
        else:
            return response

if __name__ == '__main__':
    my=ConfigHttp()
    my.test()


