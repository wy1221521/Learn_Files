import time,unittest,json
from .HTMLTestRunner import HTMLTestRunner
from .interfacecase import *
from automation_test.settings import sched
import os,django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "automation_test.settings")# project_name 项目名称
django.setup()
from interface.models import tasks,interface_cases
from django_apscheduler.jobstores import DjangoJobStore


def job_function(id):
    suite = unittest.TestSuite()
    module_list = []
    project_id = 1
    for o in tasks.objects.filter(id=id):
        project_id = o.project_id
        module_list = json.loads(o.module_list)
    for module_id in module_list:
        module_id = int(module_id)
        for p in interface_cases.objects.filter(project_id=project_id).filter(module_id=module_id):
            suite.addTest(ParametrizedTestCase.parametrize(InterfaceTest, case=p.case_id))
    runner = HTMLTestRunner(stream=None, title='接口测试报告', description='用例测试报告', TaskId=id)
    runner.run(suite)

class Aps:
    def __init__(self,TaskId,TimerRule=None):
        if TimerRule is not None:
            TimerRule = TimerRule.split()
            self.minute = TimerRule[0]
            self.hour = TimerRule[1]
            self.day = TimerRule[2]
            self.month = TimerRule[3]
            self.week = TimerRule[4]
            self.year = TimerRule[5]
        self.TaskId = TaskId
        self.sched = sched


    def StartCronJob(self):
        self.sched.start()

    def AddCronJob(self):
        self.sched.add_job(job_function, 'cron', minute=self.minute, hour=self.hour, day=self.day,
                      month = self.month, day_of_week = self.week, year = self.year,id=str(self.TaskId) , kwargs={'id': self.TaskId})
        # if self.sched.state == 0:
        #    self.sched.start()

    def RemoveCronJob(self):
        self.sched.remove_job(str(self.TaskId))

    def ModifyCronJob(self):
        self.sched.reschedule_job(job_id=str(self.TaskId), trigger='cron', minute=self.minute, hour=self.hour, day=self.day,
                      month = self.month, day_of_week = self.week, year = self.year)

