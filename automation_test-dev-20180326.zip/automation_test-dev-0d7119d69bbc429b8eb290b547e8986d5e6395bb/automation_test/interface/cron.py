#coding:utf-8
import os
import time
import datetime
from apscheduler.schedulers.blocking import BlockingScheduler
from apscheduler.schedulers.background import BackgroundScheduler

def my_job(name):
    print('Tick%s! The time is: %s' % (name, datetime.datetime.now()))

def your_job():
    print(datetime.datetime.now())

if __name__ == '__main__':
    scheduler = BackgroundScheduler()
    # for i in range(1, 5):
    scheduler.add_job(my_job, 'interval', args=(1,),seconds=1,id="1")

    scheduler.add_job(your_job, 'interval', seconds=3,id="2")
    scheduler.start()  # 这里的调度任务是独立的一个线程
    # while True:
    #   time.sleep(3)

    scheduler.reschedule_job(job_id='2', trigger='interval', seconds=5)
    while True:
        time.sleep(3)


