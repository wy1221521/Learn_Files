from django.db import models
from django.urls import reverse

# Create your models here.
class user(models.Model):
    ID=models.IntegerField
    name=models.CharField(max_length=10)

    def  __str__(self):
        return self.name
# Create your models here.
class run_temp(models.Model):
    tempname=models.CharField(null=True, max_length=10)

    def  __str__(self):
        return self.name

class projects(models.Model):
    project_id = models.AutoField(primary_key=True)
    project_name = models.CharField(max_length=20)
    project_status = models.IntegerField()
    project_createtime = models.CharField(max_length=50,null=True)
    project_creator = models.CharField(max_length=20)
    project_comments = models.TextField(null=True)

    def  __str__(self):
        return self.project_name

    def get_absolute_url(self):
        return reverse('project:table', kwargs={'pk': self.pk})


class testcase_module(models.Model):
    module_id =  models.AutoField(primary_key=True)
    module_name = models.CharField(max_length=20)
    module_createtime = models.TextField(null=True)
    module_updatetime = models.TextField(null=True)
    module_creator = models.CharField(max_length=20, null=True)
    module_updator = models.CharField(max_length=20, null=True)
    comments = models.TextField(null=True)


# class project_module(models.Model):
#     module_id = models.AutoField(primary_key=True)
#     module_name = models.CharField(max_length=20)
#     project_id = models.IntegerField(null=True)
#     module_createtime = models.CharField(max_length=50,null=True)
#     module_updatetime = models.CharField(max_length=50,null=True)
#     module_creator = models.CharField(max_length=20)
#     module_updator = models.CharField(max_length=20, null=True)
#     module_comments = models.TextField(null=True)

class interfaces(models.Model):
    interface_id=models.AutoField(primary_key=True)
    interface_host=models.CharField(max_length=255, null=True)
    interface_url=models.CharField(max_length=255, null=True)
    project_id = models.IntegerField(null=True)

class testcases(models.Model):
    id = models.AutoField(primary_key=True)
    test_id = models.CharField(max_length=20)
    topic = models.TextField(null=True)
    steps = models.TextField()
    expected = models.TextField()
    obtained = models.TextField(null=True)
    type=models.CharField(max_length=1)
    status=models.IntegerField()
    testcases_createtime = models.TextField()
    testcases_updatetime = models.TextField(null=True)
    testcases_creator = models.CharField(max_length=20,null=True)
    testcases_updator = models.CharField(max_length=20,null=True)
    comments = models.TextField(null=True)
    module_id = models.IntegerField(null=True)

class interface_cases(models.Model):
    id = models.AutoField(primary_key=True)
    case_id = models.CharField(max_length=20,unique=True)
    test_id = models.CharField(max_length=20)
    method=models.CharField(max_length=10)
    interface_id=models.IntegerField()
    module_id = models.IntegerField()
    project_id = models.IntegerField()
    head=models.TextField(null=True)
    params=models.TextField(null=True)
    data=models.TextField(null=True)
    file=models.TextField(null=True)
    status=models.IntegerField()
    testcases_createtime = models.TextField(null=True)
    testcases_updatetime = models.TextField(null=True)
    testcases_creator = models.CharField(max_length=20,null=True)
    testcases_updator = models.CharField(max_length=20,null=True)
    comments = models.TextField(null=True)
    timeout=models.IntegerField(null=True)
    expected_contents=models.TextField(null=True)


class test_results(models.Model):
    result_id=models.CharField(max_length=255)
    job_id=models.CharField(max_length=255)
    interfacecase_id=models.CharField(max_length=255)
    return_code=models.IntegerField()
    expected_contents=models.TextField()
    obtained_contents=models.TextField()
    module_id=models.IntegerField()
    project_id=models.IntegerField()
    status=models.IntegerField()
    runtime=models.TextField()

class tasks(models.Model):
    task_name = models.CharField(max_length=255, null=True)
    project_id = models.IntegerField()
    module_list = models.CharField(max_length=255, null=True)
    timer = models.CharField(max_length=255)
    timer_rule = models.CharField(max_length=255,null=True)
    task_creator = models.CharField(max_length=20,null=True)
    comments = models.TextField(null=True)

class tasks_history(models.Model):
    history_id = models.AutoField(primary_key=True)
    task_id = models.IntegerField()
    start_time = models.CharField(max_length=255,null=True)
    task_reporter = models.TextField(null=True)
    title = models.TextField(null=True)
    generator = models.TextField(null=True)
    stylesheet = models.TextField(null=True)
    heading = models.TextField(null=True)
    report = models.TextField(null=True)
    ending = models.TextField(null=True)
    chart_script = models.TextField(null=True)


class monitor_tasks(models.Model):
    task_id = models.CharField(max_length=255)
    case_id = models.CharField(max_length=255)
    project_name = models.CharField(max_length=255, null=True)
    module_name = models.CharField(max_length=255, null=True)
    status = models.IntegerField()
    begintime=models.TextField()
    cycle=models.IntegerField()
    warning_event=models.BooleanField()
    tasks_creator = models.CharField(max_length=20)


class monitor_results(models.Model):
    task_id = models.CharField(max_length=255)
    case_id = models.CharField(max_length=255)
    return_code=models.IntegerField()
    expected_contents=models.TextField()
    obtained_contents=models.TextField()
    status = models.IntegerField()
    runtime=models.TextField()

class AuthUser(models.Model):
    password = models.CharField(max_length=128)
    last_login = models.DateTimeField(blank=True, null=True)
    is_superuser = models.BooleanField()
    username = models.CharField(unique=True, max_length=150)
    first_name = models.CharField(max_length=30)
    last_name = models.CharField(max_length=30)
    email = models.CharField(max_length=254)
    is_staff = models.BooleanField()
    is_active = models.BooleanField()
    date_joined = models.DateTimeField()

    class Meta:
        managed = False
        db_table = 'auth_user'
