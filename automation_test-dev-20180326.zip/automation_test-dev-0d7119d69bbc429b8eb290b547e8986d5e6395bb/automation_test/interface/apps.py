from django.apps import AppConfig


class InterfaceConfig(AppConfig):
    name = 'interface'


    def ready(self):
        from automation_test.settings import sched
        from django_apscheduler.jobstores import DjangoJobStore
        sched.add_jobstore(DjangoJobStore(), 'default')
        sched.start()



                


