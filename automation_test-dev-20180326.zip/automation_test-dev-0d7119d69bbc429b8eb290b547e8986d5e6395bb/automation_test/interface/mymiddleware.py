from django.shortcuts import HttpResponseRedirect

try:
    from django.utils.deprecation import MiddlewareMixin  # Django 1.10.x
except ImportError:
    MiddlewareMixin = object  # Django 1.4.x - Django 1.9.x

class SimpleMiddleware(MiddlewareMixin):
    def process_request(self, request):
        if request.path !='/login_process' and request.path != '/login'  and request.path != '/register' and request.path != '/login/ajax_login' \
                and request.path !='/ajax_register' and request.path != '/registersuccess' and request.path != '/admin'  \
                and request.path !='/change_password' and request.path !='/ajax_change_password':
            if request.user.is_authenticated():
                pass
            else:
                return HttpResponseRedirect('/login')