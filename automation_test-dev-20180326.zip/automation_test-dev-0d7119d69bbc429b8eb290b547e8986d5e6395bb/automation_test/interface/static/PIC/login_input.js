function login_input() {
        var username=$("#InputUser").val();
        var password=$("#InputPassword").val();
        $.ajax({
               type:'POST',
               url:'/login/ajax_login',
               data:{'username':username,
               'password':password},  /* data内的值只允许后台使用  */

               beforeSend:function(){
               if (username==""){
               alert("请输入用户名")
/*              document.getElementById("InputUser").innerText = "请输入用户名";  */
               login_form.user.focus();
               return false;
               }
               else if (password==""){
               alert("请输入密码")
/*              document.getElementById("InputPassword").innerHTML = "<span >请输入密码</span>";  */
               login_form.password.focus();
               return false;
               }
               },
/*              success方法需注意重定向问题，登录的时候中间件会发生重定向，将链接添加至中间件， 302响应发给浏览器不直接回调ajax 而是先执行302重定向  */

               success: function(data) {
               if(data=="未授权的用户"||data=="用户名密码错误" ){
               alert(data);
               }
               else{
                   location.href = '/login_process';
               // window.open("http://192.168.0.78:8080/login_process",'_self');
               // window.open("http://127.0.0.1:8000/login_process",'_self');
               }
               },


               });
    }
   document.onkeydown=keyListener;
   function keyListener(e) {
       // 当按下回车键，执行我们的代码
       if (e.keyCode == 13) {
           login_input();
       }
   }