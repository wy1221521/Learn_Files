function initTable() {
    $('#ProjectList').bootstrapTable({
        url: '/ProjectIndex' ,              //请求后台的URL（*）
        method: 'get',                      //请求方式（*）
        toolbar: '#toolbar',                //工具按钮用哪个容器
        striped: true,                      //是否显示行间隔色
        cache: false,                       //是否使用缓存，默认为true，所以一般情况下需要设置一下这个属性（*）
        pagination: true,                   //是否显示分页（*）
        sidePagination: "client",           //分页方式：client客户端分页，server服务端分页（*）
        pageNumber: 1,                       //初始化加载第一页，默认第一页
        pageSize: 10,                       //每页的记录行数（*）
        pageList: [10, 20, 50, 100],        //可供选择的每页的行数（*）
        search: true,                       //是否显示表格搜索
        strictSearch: false,                //false 模糊搜索
        showColumns: false,                  //是否显示所有的列
        showRefresh: true,                  //是否显示刷新按钮
        singleSelect: true,
        height: 800,                        //行高，如果没有设置height属性，表格自动根据记录条数觉得表格高度
        uniqueId: "uid",                     //每一行的唯一标识，一般为主键列
        showToggle: true,                    //是否显示详细视图和列表视图的切换按钮
        cardView: false,                    //是否显示详细视图
        detailView: false,                   //是否显示父子表
        clickToSelect: true,
        maintainSelected: false,
        columns: [{
                field:'ck',
                checkbox:true,
            },{
            field: 'project_id',
            title: '序',
            align: 'center',
            sortable: true,
        }, {
            field: 'project_name',
            title: '项目名称',
            align: 'center',
            sortable: true,
        }, {
            field: 'project_status',
            title: '项目状态',
            align: 'center',
            sortable: true,
            formatter:ValueFormatter,
        }, {
            field: 'project_creator',
            title: '项目创建者',
            align: 'center',
            sortable: true,
        }, {
            field: 'project_createtime',
            title: '项目创建时间',
            align: 'center',
            sortable: true,
        },{
            field: 'project_comments',
            title: '项目描述',
            align: 'center',
            sortable: true,
        },
        //     {
        //     field: 'project_operate',
        //     title: '项目操作',
        //     align: 'center',
        //     sortable: true,
        //     formatter:OperateFormatter,
        // },
        ],
        onDblClickRow:function(row, $element){
            location.href ='/CaseList?project_id='+row.project_id+'&project_name='+row.project_name;
        }
    });
}

initTable();

function ValueFormatter(value){
    if(value == 1){
        return "进行中"
    }else if(value == 2){
       return "已完成";
   }
}


// function OperateFormatter(value,row,index){
//     return "<button class=\"btn btn-default btn-rounded btn-sm\" onClick=\"edit_row("+row.project_id+")\"><span class=\"fa fa-pencil\"></span></button>" +
//         "<button class=\"btn btn-danger btn-rounded btn-sm\" onClick=\"delete_row("+row.project_id+")\"><span class=\"fa fa-times\"></span></button>"
// }

function AddProject(){
   if($("#modify").val()==0){
        swal('权限不足','','error');
   }else{
         $("#myModal").modal('show');
   var box = $("#ModalFoot");
   box.find(".btn-primary").unbind('click');
   box.find(".btn-primary").on("click", function () {
       var ProjectName = $("#ProjectName").val();
       var ProjectStatus = $("#ProjectStatus").val();
       var ProjectDescription = $("#ProjectDescription").val();
       $.ajax({
               type:'GET',
               data:{
                  'ProjectName':ProjectName,
                  'ProjectStatus':ProjectStatus,
                  'ProjectDescription':ProjectDescription
               },
               url:'/AjaxAddProject',
               beforeSend:function () {
                   if(ProjectName ==''){
                    swal('请输入项目名称','','error');
                    return false;
                }else if(ProjectStatus ==''){
                    swal('请输入项目状态','','error');
                    return false;
                }else if(ProjectDescription ==''){
                    swal('请输入项目描述','','error');
                    return false;
                }
               },
               success:function (data) {
                   swal({
                          title: data,
                          type: "success",
                          showCancelButton: false,
                          confirmButtonColor: "#DD6B55",
                          confirmButtonText: "确定",
                          closeOnConfirm: true
                     },
                     function(){
                           $("#myModal").modal('hide');
                           $('#ProjectList').bootstrapTable('refresh');
                     });
               },
           })
   })
    }
}

function DeleteProject(){
    if($("#modify").val()==0){
        swal('权限不足','','error');
   }else {
        var selects = $('#ProjectList').bootstrapTable('getSelections');
        if (selects.length == 0) {
            swal('请选择一个项目', '', 'error');
        } else {
            swal({
                    title: "确定删除此项目?",
                    type: "warning",
                    showCancelButton: true,
                    cancelButtonText: "取消",
                    confirmButtonColor: "#DD6B55",
                    confirmButtonText: "确定",
                    closeOnConfirm: false
                },
                function () {
                    $.ajax({
                        type: 'GET',
                        data: {
                            'project_id': selects[0].project_id
                        },
                        url: '/AjaxDeleteProject',
                        success: function (data) {
                            if (data == '删除成功') {
                                swal({
                                        title: data,
                                        type: "success",
                                        showCancelButton: false,
                                        confirmButtonColor: "#DD6B55",
                                        confirmButtonText: "确定",
                                        closeOnConfirm: true
                                    },
                                    function () {
                                        $('#ProjectList').bootstrapTable('refresh');
                                    })
                            } else {
                                swal(data, '', 'warning');
                            }
                        }
                    })
                })
        }
    }
}

function EditProject(){
    if($("#modify").val()==0){
        swal('权限不足','','error');
   }else {
        var selects = $('#ProjectList').bootstrapTable('getSelections');
        if (selects.length == 0) {
            swal('请选择一个项目', '', 'error');
        } else {
            $.ajax({
                type: 'GET',
                data: {
                    'project_id': selects[0].project_id
                },
                url: '/AjaxEditProject',
                success: function (data) {
                    $("#ProjectName").val(data.project_name);
                    $("#ProjectStatus").val(data.project_status);
                    $("#ProjectDescription").val(data.project_comments);
                },
                complete: function () {
                    $("#myModal").modal('show');
                    var box = $("#ModalFoot");
                    box.find(".btn-primary").unbind('click');
                    box.find(".btn-primary").on("click", function () {
                        $.ajax({
                            type: 'GET',
                            data: {
                                'project_id': selects[0].project_id,
                                'project_name': $("#ProjectName").val(),
                                'project_status': $("#ProjectStatus").val(),
                                'project_comments': $("#ProjectDescription").val()
                            },
                            url: '/AjaxUpdateProject',
                            beforeSend: function () {
                                if ($("#ProjectName").val() == '') {
                                    swal('请输入项目名称', '', 'error');
                                    return false;
                                } else if ($("#ProjectStatus").val() == '') {
                                    swal('请输入项目状态', '', 'error');
                                    return false;
                                } else if ($("#ProjectDescription").val() == '') {
                                    swal('请输入项目描述', '', 'error');
                                    return false;
                                }
                            },
                            success: function (data) {
                                swal({
                                        title: data,
                                        text: "",
                                        type: "success",
                                        showCancelButton: false,
                                        confirmButtonColor: "#DD6B55",
                                        confirmButtonText: "确定",
                                        closeOnConfirm: true
                                    },
                                    function () {
                                        $("#myModal").modal('hide');
                                        $("#ProjectList").bootstrapTable('refresh');
                                    });
                            }
                        })
                    });
                    box.find(".btn-default").unbind('click');
                    box.find(".btn-default").on("click", function () {
                        $("#ProjectForm")[0].reset();
                        $("#myModal").modal('hide');
                    })
                }
            })
        }
    }
}

function EditUrl(){
    if($("#modify").val()==0){
        swal('权限不足','','error');
   }else {
        var selects = $('#ProjectList').bootstrapTable('getSelections');
        if (selects == "") {
            swal('请先选择', '', 'warning');
        } else {
            $("#URLModal").modal('show');
            var project_id = selects[0].project_id;
            $('#tab').empty();
            $.ajax({
                type: 'GET',
                data: {
                    'project_id': project_id,
                },
                url: '/ProjectUrl',
                success: function (data) {
                    for (i in data) {
                        var trID = data[i].interface_id + 'R';
                        $('#tab').append(
                            '<tr id="' + trID + '">' +
                            '<td class="text-center ">' + data[i].interface_host + '</td>' +
                            '<td class="text-center ">' + data[i].interface_url + '</td>' +
                            '<td class="text-center">' +
                            '<button class="btn btn-default btn-rounded btn-sm" onClick="edit_interface(' + data[i].interface_id + ')"><span class="fa fa-pencil"></span></button>' +
                            '<button class="btn btn-danger btn-rounded btn-sm" onClick="delete_interface(' + data[i].interface_id + ')"><span class="fa fa-times"></span></button>' +
                            '</td></tr>')
                    }
                }

            })
        }
    }
}

function CloseURLModal(){
    $("#URLModal").modal('hide');
    document.getElementById('add_url').disabled=false;
}

function add_URL(){
    var selects = $('#ProjectList').bootstrapTable('getSelections');
    var project_id = selects[0].project_id;
    document.getElementById('add_url').disabled=true;
    $(".btn.btn-default.btn-rounded.btn-sm").attr('disabled','true');
    $(".btn.btn-danger.btn-rounded.btn-sm").attr('disabled','true');
    $.ajax({
        type:'GET',
        url:'/InterfaceId',
        success:function(add_interface_id){
             var trID =  add_interface_id + 'R';
             $("#tab").append("<tr id='"+trID+"'>" +
               "<td class=\"text-center \"><input type='text' id='host'></td>" +
               "<td class=\"text-center \"><input type='text' id='url'></td>"+
               "<td class=\"text-center\">" +
               "<button class=\"btn btn-default btn-rounded btn-sm\" ><span class=\"fa fa-pencil\"></span></button>" +
               "<button class=\"btn btn-danger btn-rounded btn-sm\" ><span class=\"fa fa-times\"></span></button>" +
                 "</td></tr>");


                var save = document.getElementById('save');
                var revoke = document.getElementById('revoke');
                revoke.onclick = function (){
                    $('#'+trID).remove();
                    document.getElementById('add_url').disabled=false;
                    $(".btn.btn-default.btn-rounded.btn-sm").removeAttr("disabled");
                    $(".btn.btn-danger.btn-rounded.btn-sm").removeAttr("disabled");
                }

                save.onclick = function () {
                    $.ajax({
                        type:'GET',
                        url:'/SaveProjectInterface',
                        data:{
                            'interface_id':add_interface_id,
                            'project_id':project_id,
                            'host':$('#host').val(),
                            'url':$('#url').val(),
                        },
                        success:function(data){
                            document.getElementById('add_url').disabled = false;
                            $("#" + trID).children().eq("0").html(data.host);
                            $("#" + trID).children().eq("1").html(data.url);
                            $(".btn.btn-default.btn-rounded.btn-sm").removeAttr("disabled");
                            $(".btn.btn-danger.btn-rounded.btn-sm").removeAttr("disabled");
                            $("#" + trID).children('td').children(".btn.btn-default.btn-rounded.btn-sm").click(function () {
                                   edit_interface(add_interface_id);
                            });
                            $("#" + trID).children('td').children(".btn.btn-danger.btn-rounded.btn-sm").click(function () {
                                   delete_interface(add_interface_id);
                                   }
                            )
                        }
                    })
                }
        }
    })
}

function delete_interface(row){
    swal({
                  title: '确定删除此条数据？',
                  type: "warning",
                  showCancelButton: true,
                  confirmButtonColor: "#DD6B55",
                  confirmButtonText: "确定",
                  cancelButtonText: "取消",
                  closeOnConfirm: false,
                  closeOnCancel: false
                },
                function(isConfirm){
                  if(isConfirm){
                       var trID = row + 'R';
                       $.ajax({
                            type: 'GET',
                            url: '/DeleteProjectInterface',
                            data: {
                                    'interface_id': row,
                            },
                            success: function (data) {
                                    swal({
                                              title: data,
                                              type: "success",
                                              showCancelButton: false,
                                              confirmButtonColor: "#DD6B55",
                                              confirmButtonText: "确定",
                                              closeOnConfirm: true
                                         },
                                         function(){
                                              $("#"+trID).hide("slow",function(){
                                              $(this).remove();
                                              });
                                         });
                                        }
                                    }
                                    )
                                  }else{
                                      swal("已取消", "数据未删除", "error");
                                  }
                });
}

function edit_interface(row){
    var selects = $('#ProjectList').bootstrapTable('getSelections');
    var project_id = selects[0].project_id;
    var trID = row + 'R';
    $(".btn.btn-default.btn-rounded.btn-sm").attr('disabled','true');
    $(".btn.btn-danger.btn-rounded.btn-sm").attr('disabled','true');
    document.getElementById('add_url').disabled=true;
    $.ajax({
       type:'GET',
       url:"/ObtainEditInterface",
       data:{
           'interface_id':row
       },
       success:function(data) {
           $("#" + trID).children().eq("0").html("<input type='text' id='host' value=" + data.host + ">");
           $("#" + trID).children().eq("1").html("<input type='text' id='url'  value=" + data.url + ">");
           var revoke = document.getElementById('revoke');
           revoke.onclick = function () {
               $(".btn.btn-default.btn-rounded.btn-sm").removeAttr("disabled");
               $(".btn.btn-danger.btn-rounded.btn-sm").removeAttr("disabled");
               document.getElementById('add_url').disabled=false;
                 $("#" + trID).children().eq("0").html(data.host);
                 $("#" + trID).children().eq("1").html(data.url);
           }

           var save = document.getElementById('save');
           save.onclick = function () {
                $.ajax({
                    type:'GET',
                    url:'/SaveEditInterface',
                    data:{
                        'interface_id':row,
                        'host':$('#host').val(),
                        'url':$('#url').val(),
                    },
                    success:function(data){
                        $(".btn.btn-default.btn-rounded.btn-sm").removeAttr("disabled");
                        $(".btn.btn-danger.btn-rounded.btn-sm").removeAttr("disabled");
                        document.getElementById('add_url').disabled=false;
                        $("#" + trID).children().eq("0").html(data.host);
                            $("#" + trID).children().eq("1").html(data.url);
                    }
                })
           }
       }
    })
}