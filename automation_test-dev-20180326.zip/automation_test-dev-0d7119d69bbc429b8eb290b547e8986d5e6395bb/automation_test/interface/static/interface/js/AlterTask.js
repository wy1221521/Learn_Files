Array.prototype.indexOf = function(val) {
for (var i = 0; i < this.length; i++) {
if (this[i] == val) return i;
}
return -1;
};

Array.prototype.remove = function(val) {
var index = this.indexOf(val);
if (index > -1) {
this.splice(index, 1);
}
};

$(document).ready(function(){
//    $("#SelectProject").select2({
//       placeholder:'请选择',
//       ajax: {
//         url: "/SelectProject",
//         dataType: 'json',
//         delay: 250,
//         data: function (params) {
//           return {
//             search: params.term,
//           };
//         },
//         processResults: function (data) {
//           return {
//             results: data
//           };
//         },
//         cache: true
//       },
//     }
// );
    $("#SelectProject").select2()
   $.ajax({
     type:'GET',
     data:{
         'project_id':$('#project_id').val(),
     },
     url:'/AddSelectProject'
    }).then(
    function(data){
        var option = new Option(data.text, data.id, true, true);
        $("#SelectProject").append(option).trigger('change');
        $("#SelectProject").trigger({
            type: 'select2:select',
            params: {
                data: data,
            }
        })
    }
);

$("#SelectProject").on('select2:select',function(e) {
    var data = e.params.data;
    $.ajax({
        type: 'GET',
        data: {
            'project_id': data.id,
        },
        url: '/ModelCheck',
        success: function (data) {
            $('#ModelDiv').empty();
            for (i = 0;i<data.length;i++) {
                if (i % 5 == 4) {
                    $('#ModelDiv').append("<input type='checkbox' value='" + data[i].module_id + "'><label>" + data[i].module_name + "&nbsp;" + "&nbsp;" + "&nbsp;" + "&nbsp;" + "</label></br></br> ")
                } else {
                    $('#ModelDiv').append("<input type='checkbox' value='" + data[i].module_id + "'><label>" + data[i].module_name + "&nbsp;" + "&nbsp;" + "&nbsp;" + "&nbsp;" + "</label> ")
                }
            }
            var module_list = $('#module_list').val();
            var m1 = $('#module_list').val().split("'");
            m1.remove(']');
            m1.remove('[');
            m1.remove(', ');
            for(j = 0; j < m1.length; j++){
                var module_value = parseInt(m1[j]);
                $("input[type$='checkbox'][value$="+module_value+"]").iCheck('check');
            }
           check();
        }
    })
});

check();
if($('#TimerValue').val() == 'true'){
            $('#timer').iCheck('check');
        }else{
            $('#timer').iCheck('uncheck');
        }

});

function check() {
  $('input').iCheck({
            checkboxClass: 'icheckbox_square-blue',
            radioClass: 'iradio_square-blue',
            increaseArea: '20%' // optional
     });
  $('#timer').on('ifChecked', function(event){
        $("#TimerRule").attr("disabled",false);
    });


  $('#timer').on('ifUnchecked', function(event){
   $("#TimerRule").attr("disabled",true);
    });

}



function ConfirmModify() {
    var id = $('#id').val();
    var TaskName = $('#TaskName').val();
    var comments = $('#comments').val();
    var timer = $("input[id='timer']").is(':checked');
    var TimerRule = $('#TimerRule').val();
    var SelectModelList = new Array();
    var SelectModel = $("#ModelDiv div.checked").children(":checkbox");//获取id为ModelDiv下的 div class为checked的子元素,子元素中的checkbox
    SelectModel.each(function(){               //each 遍历jquery元素
        SelectModelList.push($(this).val());
    });
    var ModelList = JSON.stringify(SelectModelList);
    $.ajax({
        type:'GET',
        data:{
            'id':id,
            'TaskName':TaskName,
            'comments':comments,
            'timer':timer,
            'TimerRule':TimerRule,
            'ModelList':ModelList,
        },
        url:'/UpdateTask',
        beforeSend:function () {
                   if(TaskName ==''){
                    swal('请输入任务名称','','error');
                    return false;
                   }else if(comments == ''){
                    swal('请输入任务描述','','error');
                    return false;
                   }else if(SelectModelList.length == 0){
                     swal('请选择模块','','error');
                     return false;
                   }else if(cronValidate(TimerRule) == false){
                     swal('请输入正确的定时规则','','error');
                     return false;
                   }
               },
        success:function(data){
            swal({
                  title: "更新成功",
                  type: "success",
                  showCancelButton: true,
                  confirmButtonColor: "#DD6B55",
                  confirmButtonText: "返回上一页",
                  cancelButtonText: "留在当前页",
                  closeOnConfirm: false,
                  closeOnCancel: true,
                },
                function(isConfirm){
                  if (isConfirm) {
                    location.href = '/TaskList';
                  }
                });
        }
    })
}