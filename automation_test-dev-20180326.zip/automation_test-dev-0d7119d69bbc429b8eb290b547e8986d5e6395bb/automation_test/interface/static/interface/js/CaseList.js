function initTable(x) {
    $('#CaseList').bootstrapTable({
        url: '/CaseIndex?project_id='+x ,    //请求后台的URL（*）
        method: 'get',                      //请求方式（*）
        toolbar: '#toolbar',                //工具按钮用哪个容器
        striped: true,                      //是否显示行间隔色
        cache: false,                       //是否使用缓存，默认为true，所以一般情况下需要设置一下这个属性（*）
        pagination: true,                   //是否显示分页（*）
        sidePagination: "client",           //分页方式：client客户端分页，server服务端分页（*）
        pageNumber: 1,                      //初始化加载第一页，默认第一页
        pageSize: 10,                       //每页的记录行数（*）
        pageList: [10, 20, 50, 100,200],        //可供选择的每页的行数（*）
        search: true,                       //是否显示表格搜索
        strictSearch: false,                //false 模糊搜索
        showColumns: false,                 //是否显示所有的列
        showRefresh: true,                  //是否显示刷新按钮
        singleSelect: false,
        height: 800,                        //行高，如果没有设置height属性，表格自动根据记录条数觉得表格高度
        uniqueId: "uid",                    //每一行的唯一标识，一般为主键列
        showToggle: true,                   //是否显示详细视图和列表视图的切换按钮
        cardView: false,                    //是否显示详细视图
        detailView: false,                  //是否显示父子表
        clickToSelect: true,
        maintainSelected: false,
        columns: [ {
                field:'ck',
                checkbox:true,
            },{
            field: 'case_id',
            title: '用例编号',
            align: 'center',
            sortable: true,
        },  {
            field: 'module_name',
            title: '模块名',
            align: 'center',
            sortable: true,
        },{
            field: 'case_topic',
            title: '用例主题',
            align: 'center',
            sortable: true,
        },  {
            field: 'host',
            title: '主机',
            align: 'center',
            sortable: true,
        }, {
            field: 'url',
            title: '资源定位地址',
            align: 'center',
            sortable: true,
        },{
            field: 'method',
            title: '请求方式',
            align: 'center',
            sortable: true,
        }, {
            field: 'params',
            title: 'params',
            align: 'center',
            sortable: true,
        },{
            field: 'head',
            title: 'headers',
            align: 'center',
            sortable: true,
        },{
            field: 'data',
            title: '入参',
            align: 'center',
            sortable: true,
        },{
            field: 'timeout',
            title: '时限(秒)',
            align: 'center',
            sortable: true,
        },{
            field: 'expected_contents',
            title: '期待返回内容',
            align: 'center',
            sortable: true,
        },{
            field: 'comments',
            title: '描述',
            align: 'center',
            sortable: true,
        },{
            field: 'status',
            title: '状态',
            align: 'center',
            sortable: true,
            formatter:StatusFormatter,
         },
        ],
    });
}

initTable($("#project_id").val());

function StatusFormatter(value,row,index) {
    if (value == 0){
        return "<span class='label label-success'>通过</span>"
    }else if(value ==1){
        return "<span class='label label-default'>失败</span>"
    }else if(value ==2){
        return "<span class='label label-danger'>错误</span>"
    }else if(value ==3){
        return "<span class='label label-info'>新建</span>"
    }
}

// function OperateFormatter(value,row,index){
//     return "<button class='btn btn-warning'>编辑</button>" +
//         "<button class='btn btn-info' onclick='execute(\""+row.case_id+"\")'>执行</button>" +
//         "<button class='btn btn-danger'>删除</button>";
// }

function AddCase(){
    if($("#modify").val()==0){
        swal('权限不足','','error');
   }else {
        $("#myModal").modal('show');
    var box = $("#ModalFoot");
    box.find(".btn-success").unbind('click');
    box.find(".btn-success").on("click", function () {
        var formData = new FormData();
        var project_id = $("#project_id").val();
        var CaseId = $("#CaseId").val();
        var module_id = $("#CaseModel").val();
        var CaseTopic = $("#CaseTopic").val();
        var CaseInterfaceUrl = $("#CaseInterfaceUrl").val();
        var method = $("#method").val();
        var status = $("#status").val();
        var timeout = $("#timeout").val();
        var headers = $("#headers").val();
        var data = $("#data").val();
        var expected_contents = $("#expected_contents").val();
        var params = $("#params").val();
        var comments = $("#comments").val();

        formData.append('project_id',project_id);
        formData.append('CaseId',CaseId);
        formData.append('module_id',module_id);
        formData.append('CaseTopic',CaseTopic);
        formData.append('CaseInterfaceUrl',CaseInterfaceUrl);
        formData.append('method',method);
        formData.append('status',status);
        formData.append('timeout',timeout);
        formData.append('headers',headers);
        formData.append('data',data);
        formData.append('expected_contents',expected_contents);
        formData.append('params',params);
        formData.append('comments',comments);
        formData.append('file',$('#file')[0].files[0]);
       $.ajax({
               type:'POST',
               data:formData,
               processData: false,
               // 告诉jQuery不要去设置Content-Type请求头
               contentType: false,
               url:'/AjaxAddCase',
               beforeSend:function () {
                   if(CaseId ==''){
                    swal('请输入用例编号','','error');
                    return false;
                   }else if(module_id ==null){
                    swal('请输入用例模块','','error');
                    return false;
                   }else if(CaseInterfaceUrl ==null){
                    swal('请输入用例接口地址','','error');
                    return false;
                   }else if(!/^\d+$|^\d+\.\d+$/g.test(timeout)){
                    swal('请输入正确的时间','','error');
                    return false;
                   }
               },
               success:function (data) {
                   if(data =='新建成功'){
                       swal({
                          title: data,
                          type: "success",
                          showCancelButton: false,
                          confirmButtonColor: "#DD6B55",
                          confirmButtonText: "确定",
                          closeOnConfirm: true
                     },
                     function(){
                           $("#myModal").modal('hide');
                           $('#CaseList').bootstrapTable('refresh');
                     });
                   }else{
                       swal(data,'','error');
                   }
               }
           })
   })
    }

}

function Execute(data) {
    var selects = $('#CaseList').bootstrapTable('getSelections');
    if (selects.length == 0) {
        swal('请至少选择一个用例', '', 'error');
    } else {
        var ii = layer.load();
        var SelectsCaseIdList = new Array();
        for (i in selects) {
            SelectsCaseIdList.push(selects[i].case_id);
        }
        $.ajax({
            type: 'GET',
            data: {
                'SelectsCaseIdList': JSON.stringify(SelectsCaseIdList)
            },
            url: '/ExecuteCase',
            success: function (ddd) {
                layer.close(ii);
                $("#CaseList").bootstrapTable('refresh');
                window.open("/OpenHtml?file="+ddd, "_blank");
            }
        })
    }
}

function AlterCase() {
    if ($("#modify").val() == 0) {
        swal('权限不足', '', 'error');
    } else {
        var selects = $('#CaseList').bootstrapTable('getSelections');
        if (selects.length != 1) {
            swal('请选择一个用例进行修改', '', 'error');
        } else {
            var CaseId = selects[0].case_id;
            $.ajax({
                type: 'GET',
                data: {
                    'CaseId': CaseId
                },
                url: '/AjaxAlterCase',
                success: function (data) {
                    $("#CaseId").val(CaseId);

                    $.ajax({
                        type: 'GET',
                        data: {
                            'module_id': data.module_id,
                        },
                        url: '/AddSelectModule'
                    }).then(
                        function (data) {
                            var option = new Option(data.text, data.id, true, true);
                            $("#CaseModel").append(option).trigger('change');
                            $("#CaseModel").trigger({
                                type: 'select2:select',
                                params: {
                                    data: data,
                                }
                            })
                        }
                    );
                    $.ajax({
                        type: 'GET',
                        data: {
                            'case_topic': data.case_topic,
                        },
                        url: '/AddSelectTopic'
                    }).then(
                        function (data) {
                            var option = new Option(data.text, data.id, true, true);
                            $("#CaseTopic").append(option).trigger('change');
                            $("#CaseTopic").trigger({
                                type: 'select2:select',
                                params: {
                                    data: data,
                                }
                            })
                        }
                    );

                    $.ajax({
                        type: 'GET',
                        data: {
                            'interface_id': data.interface_id,
                        },
                        url: '/AddSelectInterface'
                    }).then(
                        function (data) {
                            var option = new Option(data.text, data.id, true, true);
                            $("#CaseInterfaceUrl").append(option).trigger('change');
                            $("#CaseInterfaceUrl").trigger({
                                type: 'select2:select',
                                params: {
                                    data: data,
                                }
                            })
                        }
                    );

                    $("#method").val(data.method);
                    $("#status").val(data.status);
                    $("#timeout").val(data.timeout);
                    $("#headers").val(data.head);
                    $("#data").val(data.data);
                    $("#expected_contents").val(data.expected_contents);
                    $("#params").val(data.params);
                    $("#comments").val(data.comments);
                    $("#CaseId").attr("disabled", true);
                },
                complete: function () {
                    $("#myModal").modal('show');
                    var box = $("#ModalFoot");
                    box.find(".btn-success").unbind('click');
                    box.find(".btn-success").on("click", function () {
                        $.ajax({
                            type: 'GET',
                            data: {
                                'CaseId': CaseId,
                                'module_id': $("#CaseModel").val(),
                                'CaseTopic': $("#CaseTopic").val(),
                                'CaseInterfaceUrl': $("#CaseInterfaceUrl").val(),
                                'method': $("#method").val(),
                                'status': $("#status").val(),
                                'timeout': $("#timeout").val(),
                                'headers': $("#headers").val(),
                                'data': $("#data").val(),
                                'expected_contents': $("#expected_contents").val(),
                                'params': $("#params").val(),
                                'comments': $("#comments").val(),

                            },
                            url: '/AjaxUpdateCase',
                            beforeSend: function () {
                                if (!/^\d+$|^\d+\.\d+$/g.test($("#timeout").val())) {
                                    swal('请输入正确的时间', '', 'error');
                                    return false;
                                }
                            },
                            success: function (data) {
                                swal({
                                        title: data,
                                        text: "",
                                        type: "success",
                                        showCancelButton: false,
                                        confirmButtonColor: "#DD6B55",
                                        confirmButtonText: "确定",
                                        closeOnConfirm: true
                                    },
                                    function () {
                                        $("#myModal").modal('hide');
                                        $("#CaseList").bootstrapTable('refresh');
                                    });
                            }
                        })
                    });
                    box.find(".btn-default").unbind('click');
                    box.find(".btn-default").on("click", function () {
                        $("#CaseForm")[0].reset();
                        $("#CaseId").attr("disabled", false);
                        $("#myModal").modal('hide');
                    })
                }
            })
        }
    }
}

function DeleteCase() {
    if ($("#modify").val() == 0) {
        swal('权限不足', '', 'error');
    } else {
        var selects = $('#CaseList').bootstrapTable('getSelections');
        if (selects.length == 0) {
            swal('请至少选择一个用例', '', 'error');
        } else {
            var SelectsCaseIdList = new Array();
            for (i in selects) {
                SelectsCaseIdList.push(selects[i].case_id);
            }
            swal({
                    title: "确定删除指定的用例吗?",
                    text: "您将无法恢复指定的用例!",
                    type: "warning",
                    showCancelButton: true,
                    confirmButtonColor: "#DD6B55",
                    cancelButtonText: "取消",
                    confirmButtonText: "确定",
                    closeOnConfirm: false
                },
                function () {
                    $.ajax({
                        type: 'GET',
                        data: {'SelectsCaseIdList': JSON.stringify(SelectsCaseIdList)},
                        dataType: "json",
                        url: '/AjaxDeleteCase',
                        success: function (data) {
                            swal({
                                    title: data,
                                    text: "",
                                    type: "success",
                                    showCancelButton: false,
                                    confirmButtonColor: "#DD6B55",
                                    confirmButtonText: "确定",
                                    closeOnConfirm: true
                                },
                                function () {
                                    $("#CaseList").bootstrapTable('refresh');
                                });

                        }
                    })
                });
        }
    }
}

$("#CaseModel").select2({
      placeholder:'请选择',
      ajax: {
        url: "/SelectModel",
        dataType: 'json',
        delay: 250,
        data: function (params) {
          return {
            search: params.term,
          };
        },
        processResults: function (data) {
          return {
            results: data
          };
        },
        cache: true
      },
    }
);

$("#CaseTopic").select2();    //初始化

$("#CaseModel").on('select2:select',function(e){
    $("#CaseTopic").empty();   //清空
    var data = e.params.data;
    $.ajax({
        type:'GET',
        data:{
            'module_id':data.id,
        },
        url:'/ShowTopic',
        success:function(data){
            $("#CaseTopic").select2({data: data})
        }
    })
}
);

$("#CaseInterfaceUrl").select2({
      placeholder:'请选择',
      ajax: {
        url: "/SelectURL",
        dataType: 'json',
        delay: 250,
        data: function (params) {
          return {
            'project_id':$('#project_id').val(),
            search: params.term,
          };
        },
        processResults: function (data) {
          return {
            results: data
          };
        },
        cache: true
      },
    });



