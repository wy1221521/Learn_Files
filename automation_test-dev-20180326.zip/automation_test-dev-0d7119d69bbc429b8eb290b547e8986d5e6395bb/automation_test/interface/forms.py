from django import forms

class editform(forms.Form):
    topic = forms.CharField()
    type = forms.CharField(max_length=1)
    status = forms.IntegerField()
    steps = forms.CharField()
    expected = forms.CharField()
    testcases_updatetime = forms.DateTimeField(auto_now=True, null=True)
    testcases_updator = forms.CharField(max_length=20, null=True)
    comments = forms.CharField(null=True)
