#coding:utf-8
import re
import datetime
from interface.models import test_results
from django.http import HttpResponse,HttpResponseRedirect

def check_equal(param1, param2):
    if  param1 == param2:
        return 0
    else:

        return 1

def check_code(statu):
    if re.match("2\d+", str(statu)):
        # print("********测试通过********")
        return 0
    elif re.match("3\d+", str(statu)):
        return 1
    elif re.match("4\d+", str(statu)):
        return 1
    elif re.match("5\d+", str(statu)):
        return 1

def check_contents(expected_content, obtained_contents):
     obtained_contents = obtained_contents.replace("\n","").replace("\t","").replace("\r","").replace(" ","").replace("\"","")
     expected_content = expected_content.replace("\n","").replace("\t","").replace("\r","").replace(" ","").replace("\"","")
     if  expected_content in obtained_contents:
         return 0
     else:
         return 1

def save_result(*args):
    result_id = args[0]+datetime.datetime.now()
    job_id = args[1]
    interfacecase_id = args[0]
    return_code =  args[2]
    expected_contents =  args[3]
    obtained_contents =  args[4]
    module_id =  args[5]
    project_id =  args[6]
    status =  args[7]
    try:
        test_results.objects.create(result_id=result_id, job_id=job_id, interfacecase_id=interfacecase_id,
                                    return_code=return_code, expected_contents=expected_contents, obtained_contents=obtained_contents,
                                    module_id=module_id, project_id=project_id, status=status,
                                    runtime=datetime.datetime.now())
    except:
        ''''''
        return HttpResponse("新建失败")
    else:
        return HttpResponseRedirect('/tasklist/')