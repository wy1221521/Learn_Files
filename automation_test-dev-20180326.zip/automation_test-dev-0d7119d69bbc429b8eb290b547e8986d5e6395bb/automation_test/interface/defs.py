from django.http import JsonResponse
from .models import AuthUser
from django.shortcuts import render
from django.contrib.auth.models import User
from django.contrib.auth import authenticate,login,logout


# Create your views here.
def start(request):
    return render(request,'login/pages-login-website-light.html')

#打开登录功能
def login1(request):  #会和内置login方法冲突，所以写成login1
    return render(request, 'login/pages-login-website-light.html')

#登录功能前后端交互
def ajax_login(request):
    username= request.POST['username']
    password= request.POST['password']
    user=authenticate(username=username, password=password)
    if user is not None:
        if user.is_active:
             login(request,user)
             context = "登录成功"
             request.session['IS_LOGIN'] = True     #设置session，django中session已写好，会自动存入cookie
             # LogConfig.logger.info('登入记录:[IP:'+request.META['REMOTE_ADDR']+',用户名:'+str(request.user)+']')
        else:
             context="未授权的用户"

    else:
             context="用户名密码错误"
    return JsonResponse(context, safe=False)


def login_process(request):
    # if not request.user.has_perm('purchase_data.able_operation'):
    #     edit = 1
    # else:
    #     edit = 0
    # A = {
    #     "edit": edit
    # }
    return render(request, 'interface/home.html')

def cancel(request):
    # LogConfig.logger.info('登出记录:[IP:' + request.META['REMOTE_ADDR'] + ',用户名:' + str(request.user) + ']')
    logout(request)  # 用户登出
    request.session['IS_LOGIN'] = False
    return render(request, 'login/pages-login-website-light.html')

#打开用户注册功能
def register(request):
    return render(request, 'login/pages-user-register.html')


#注册功能前端后台交互
def ajax_register(request):
    user_list=[]
    email_list=[]
    user = request.POST['user']
    email = request.POST['email']
    user_objects = AuthUser.objects.distinct('username')
    email_objects= AuthUser.objects.distinct('email')
    for exist_user in user_objects:
        user_list.append(exist_user.username)
    for exist_email in email_objects:
        email_list.append(exist_email.email)
    if user in user_list or email in email_list:
        message = "用户名或邮箱已存在"
    else:
        message = "注册成功"
    return JsonResponse(message,safe=False)


#判断无误进行注册并返回至首页
def registersuccess(request):
    A=[]
    name = request.POST['user']
    email= request.POST['email']
    password=request.POST['password1']
    user = User.objects.create_user(name, email, password)
    login(request,user)
    return render(request, 'interface/home.html')

def change_password(request):
    return render(request, 'login/pages-user-password.html')

def ajax_change_password(request):
    username = request.POST['user']
    old_password = request.POST['password']
    new_password = request.POST['password1']
    user = authenticate(username=username, password=old_password)
    if user is not None and user.is_active:
        user.set_password(new_password)
        user.save()
        message = "修改成功"
    else:
        message = "旧密码不匹配"
    return JsonResponse(message,safe=False)